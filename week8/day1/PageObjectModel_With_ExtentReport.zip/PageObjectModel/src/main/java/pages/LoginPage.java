package pages;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import base.BaseClass;

public class LoginPage extends BaseClass{
	
	
	public LoginPage(ChromeDriver driver) {
		this.driver = driver;
					
	}
	
	public LoginPage enterUsername(String username) throws InterruptedException, IOException {
		try {
			driver.findElement(By.id("username")).sendKeys(username);
			reportStep(username+" Username is entered successfully", "pass");
		} catch (Exception e) {
			reportStep("Username is not entered successfully "+e, "fail");
		} 
		return this;
	}
	
	
	public LoginPage enterPassword(String password) throws IOException {
		try {
			driver.findElement(By.id("password")).sendKeys(password);
			reportStep(password+" password is entered successfully", "pass");
		} catch (Exception e) {
			reportStep("password is not entered successfully", "fail");
		} 
		return this;
	}
	

	public HomePage clickLoginButton() throws IOException {
		try {
			driver.findElement(By.className("decorativeSubmit")).click();
			reportStep("Login button is clicked", "pass");
		} catch (Exception e) {
			reportStep("Login button is not clicked", "fail");
		}
		return new HomePage(driver);
	}
	
	public LoginPage clickLoginForNegativeData() {
		driver.findElement(By.className("decorativeSubmit")).click();
		return this;
	}
	
	
	
	
	
	
	
	
	
	
	
		

}
