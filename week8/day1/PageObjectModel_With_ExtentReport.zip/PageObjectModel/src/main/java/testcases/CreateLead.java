package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class CreateLead extends BaseClass{
	
	@BeforeTest
	public void setData() {
		fileName = "CreateLead";
		testName = "CreateLead";
		testDescription = "CreateLead with mandatory informations";
		testCategory = "regression";
		testAuthor = "Hari";
	}
	
	@Test(dataProvider = "sendData")
	public void runCreateLead(String username, String password, String company, String firstName, String lastName) throws InterruptedException, IOException {
				
		new LoginPage(driver)
		.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton()
		.clickCrmsfaLink()
		.clickLeadsLink()
		.clickCreateLeadLink()
		.enterFirstName(firstName)
		.enterLastName(lastName)
		.enterCompanyName(company)
		.clickCreateLeadButton()
		.verifyFirstName();

	}

}
