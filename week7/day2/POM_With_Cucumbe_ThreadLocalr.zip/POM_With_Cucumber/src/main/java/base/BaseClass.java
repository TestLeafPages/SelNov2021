package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.github.bonigarcia.wdm.WebDriverManager;
import utils.ReadExcel;

public class BaseClass  extends AbstractTestNGCucumberTests{
	
	
	private static final ThreadLocal<RemoteWebDriver> remoteWebDriver = new ThreadLocal<RemoteWebDriver>();
	
	//setter method
	public void setDriver() {
		remoteWebDriver.set(new ChromeDriver());
	}
	
	//getter method
	public RemoteWebDriver getDriver() {
		return remoteWebDriver.get();
	}
	
	@BeforeMethod
	public void preCondition() {
		WebDriverManager.chromedriver().setup();
	//	driver = new ChromeDriver(); // driver is initialized "sdadq442342dfdff"
		setDriver();
		getDriver().manage().window().maximize();
		getDriver().get("http://leaftaps.com/opentaps/control/main");
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

	}
	

//	public static ChromeDriver driver; // driver = null

	public String fileName;

	@DataProvider
	public String[][] sendData() throws IOException {

		return ReadExcel.readData(fileName);

	}

	

	@AfterMethod
	public void postCondition() {
		getDriver().close();

	}

}
