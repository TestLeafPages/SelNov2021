package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import base.BaseClass;
import io.cucumber.java.en.Then;

public class HomePage extends BaseClass{
	

	
	public MyHomePage clickCrmsfaLink() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();

		return new MyHomePage();
	}
	
	public LoginPage clickLogout() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		
		return new LoginPage();
	}
	
	@Then("Home page should be displayed")
	public HomePage verifyHomePage() {
		
		boolean displayed = getDriver().findElement(By.linkText("CRM/SFA")).isDisplayed();
		Assert.assertTrue(displayed);
			
		return this;
		
	}
	
	

}
