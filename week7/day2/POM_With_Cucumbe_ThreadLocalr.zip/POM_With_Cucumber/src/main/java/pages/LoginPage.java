package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends BaseClass{
	
	
	
	@Given("Enter username as {string}")
	public LoginPage enterUsername(String username) throws InterruptedException {
		getDriver().findElement(By.name("USERNAME")).sendKeys(username);
		//		Thread.sleep(10000);
		return this;
	}
	
	@Given("Enter password as {string}")
	public LoginPage enterPassword(String password) {
		
		getDriver().findElement(By.id("password")).sendKeys(password);
		
		return this;
	}
	
	@When("Click on login button")
	public HomePage clickLoginButton() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		
		return new HomePage();
	}
	
	
	
	
	
	
	
	
	
	
	
	
		

}
