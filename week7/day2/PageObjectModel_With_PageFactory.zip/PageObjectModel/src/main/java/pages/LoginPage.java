package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import base.BaseClass;

public class LoginPage extends BaseClass{
	
	
	public LoginPage(ChromeDriver driver) {
		this.driver = driver;
		
		PageFactory.initElements(driver, this);
		
	}
	
	@CacheLookup
	@FindBy(how = How.CLASS_NAME, using="inputLogin") List<WebElement> eleInputLogin;
	
	@CacheLookup
	@FindBy(how = How.CLASS_NAME, using = "decorativeSubmit") WebElement eleLogin;
	
	/*
	 * @FindAll( {
	 * 
	 * @FindBy(how=How.CLASS_NAME,using="inputLogin123"),
	 * 
	 * @FindBy(how=How.XPATH, using="//input[@id='username']") } ) WebElement
	 * eleUsername;
	 */
	
	/*
	 * @FindBys( {
	 * 
	 * @FindBy(how=How.CLASS_NAME,using="inputLogin123"),
	 * 
	 * @FindBy(how=How.XPATH, using="//input[@id='username']") } ) WebElement
	 * eleUsername;
	 */
	
	
	
	//@FindBy(how = How.ID, using="password") WebElement elePassword;
	
	
	
	public LoginPage enterUsername(String username) throws InterruptedException {
		eleInputLogin.get(0).sendKeys(username);
		
	//	eleUsername.sendKeys(username);
		return this;
	}
	
	
	public LoginPage enterPassword(String password) {
	//	elePassword.sendKeys(password);
		eleInputLogin.get(1).sendKeys(password);
		return this;
	}
	

	public HomePage clickLoginButton() {
		eleLogin.click();
		return new HomePage(driver);
	}
	
	public LoginPage clickLoginForNegativeData() {
		eleLogin.click();
		return this;
	}
	
	
	
	
	
	
	
	
	
	
	
		

}
